-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 �?01 �?09 �?09:06
-- 服务器版本: 5.5.53-log
-- PHP 版本: 5.5.38

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `webconsole`
--

-- --------------------------------------------------------

--
-- 替换视图以便查看 `main_seo`
--
CREATE TABLE IF NOT EXISTS `main_seo` (
`domain_id` int(6) unsigned
,`domain` varchar(128)
,`domain_name` varchar(64)
,`web_type` enum('PC','移动站','自适应')
,`main_program` varchar(32)
,`host_url` varchar(128)
,`host_user` varchar(32)
,`host_pwd` varchar(32)
,`web_ldomain` varchar(128)
,`web_lrat` int(10) unsigned
,`web_srat` int(10) unsigned
,`web_refer` varchar(128)
,`is_moblie` enum('否','是')
,`mobile_refer` varchar(128)
,`agent` varchar(32)
,`domain_rat` int(10) unsigned
,`agent_rat` int(10) unsigned
,`seo_id` int(6) unsigned
,`seo_keywords` varchar(512)
);
-- --------------------------------------------------------

--
-- 替换视图以便查看 `main_server`
--
CREATE TABLE IF NOT EXISTS `main_server` (
`domain_id` int(6) unsigned
,`domain` varchar(128)
,`domain_name` varchar(64)
,`web_type` enum('PC','移动站','自适应')
,`main_program` varchar(32)
,`host_url` varchar(128)
,`host_user` varchar(32)
,`host_pwd` varchar(32)
,`web_ldomain` varchar(128)
,`web_lrat` int(10) unsigned
,`web_srat` int(10) unsigned
,`web_refer` varchar(128)
,`is_moblie` enum('否','是')
,`mobile_refer` varchar(128)
,`agent` varchar(32)
,`domain_rat` int(10) unsigned
,`agent_rat` int(10) unsigned
,`server_id` int(6) unsigned
,`ftp_ip` varchar(128)
,`ftp_user` varchar(32)
,`ftp_pwd` varchar(32)
,`mysql_ip` varchar(128)
,`mysql_user` varchar(32)
,`mysql_pwd` varchar(32)
,`console_domain` varchar(128)
,`console_user` varchar(32)
,`console_pwd` varchar(32)
);
-- --------------------------------------------------------

--
-- 替换视图以便查看 `main_server_seo`
--
CREATE TABLE IF NOT EXISTS `main_server_seo` (
`domain_id` int(6) unsigned
,`domain` varchar(128)
,`domain_name` varchar(64)
,`web_type` enum('PC','移动站','自适应')
,`main_program` varchar(32)
,`host_url` varchar(128)
,`host_user` varchar(32)
,`host_pwd` varchar(32)
,`web_ldomain` varchar(128)
,`web_lrat` int(10) unsigned
,`web_srat` int(10) unsigned
,`web_refer` varchar(128)
,`is_moblie` enum('否','是')
,`mobile_refer` varchar(128)
,`agent` varchar(32)
,`domain_rat` int(10) unsigned
,`agent_rat` int(10) unsigned
,`server_id` int(6) unsigned
,`ftp_ip` varchar(128)
,`ftp_user` varchar(32)
,`ftp_pwd` varchar(32)
,`mysql_ip` varchar(128)
,`mysql_user` varchar(32)
,`mysql_pwd` varchar(32)
,`console_domain` varchar(128)
,`console_user` varchar(32)
,`console_pwd` varchar(32)
,`seo_id` int(6) unsigned
,`seo_keywords` varchar(512)
);
-- --------------------------------------------------------

--
-- 表的结构 `web_main`
--

CREATE TABLE IF NOT EXISTS `web_main` (
  `domain_id` int(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '网站ID',
  `domain` varchar(128) NOT NULL COMMENT '网站域名',
  `domain_name` varchar(64) NOT NULL COMMENT '网站名',
  `web_type` enum('PC','移动站','自适应') DEFAULT NULL COMMENT '网站类型',
  `main_program` varchar(32) DEFAULT NULL COMMENT '网站主程序',
  `host_url` varchar(128) DEFAULT NULL COMMENT '网站后台登录地址',
  `host_user` varchar(32) DEFAULT NULL COMMENT '后台登录账号',
  `host_pwd` varchar(32) DEFAULT NULL COMMENT '后台登录密码',
  `web_ldomain` varchar(128) DEFAULT NULL COMMENT '本地建站域名',
  `web_lrat` int(10) unsigned DEFAULT '0' COMMENT '本地建站完成时间',
  `web_srat` int(10) unsigned DEFAULT '0' COMMENT '网站上线时间',
  `web_refer` varchar(128) DEFAULT NULL COMMENT '参考站',
  `is_moblie` enum('否','是') DEFAULT NULL COMMENT '是否存在独立移动站',
  `mobile_refer` varchar(128) DEFAULT NULL COMMENT '移动站参考站',
  `agent` varchar(32) DEFAULT NULL COMMENT '代理商',
  `domain_rat` int(10) unsigned NOT NULL COMMENT '域名注册时间',
  `agent_rat` int(10) unsigned DEFAULT '0' COMMENT '主机注册时间',
  PRIMARY KEY (`domain_id`),
  UNIQUE KEY `domain` (`domain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='网站主信息' AUTO_INCREMENT=144 ;

--
-- 转存表中的数据 `web_main`
--

INSERT INTO `web_main` (`domain_id`, `domain`, `domain_name`, `web_type`, `main_program`, `host_url`, `host_user`, `host_pwd`, `web_ldomain`, `web_lrat`, `web_srat`, `web_refer`, `is_moblie`, `mobile_refer`, `agent`, `domain_rat`, `agent_rat`) VALUES
(120, 'www.test.com', '测试站', 'PC', 'html', 'www.test.com', 'test11', 'test', 'www.test.com', 1546099200, 1546099200, '无', '否', '无', '无', 1516377600, 1516377600),
(126, 'www.test4.com', '测试站点4', 'PC', 'PHP', 'www.test4.com', 'test4', 'test', 'www.test4.com', 1546444800, 1546444800, '无', '否', '无', '无', 1516377600, 1546444800),
(132, 'www.test5.com', '测试站5', 'PC', 'PHP', 'www.test5.com', 'test5', 'test', 'www.test5.com', 1546531200, 1546531200, '无', '否', '无', '无', 1515254400, 1546531200),
(133, 'www.test6.com', '测试站6', 'PC', 'PHP', 'www.test6.com', 'test6', 'test', 'www.test6.com', 1546531200, 1546531200, '无', '否', '无', '无', 1546531200, 1546531200),
(134, 'www.test2.com', '测试站2', 'PC', 'PHP', 'www.test2.com', 'test2', 'test', 'www.test2.com', 1546531200, 1546531200, '无', '否', '无', '无', 1546531200, 1546531200),
(135, 'www.test3.com', '测试站3', 'PC', 'PHP', 'www.test3.com', 'test3', 'test', 'www.test3.com', 1546531200, 1546531200, '无', '否', '无', '无', 1546531200, 1546531200),
(136, 'www.test8.com', '测试站8', 'PC', 'PHP', 'www.test8.com', 'test8', 'test', 'www.test8.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400),
(137, 'www.test9.com', '测试站9', 'PC', 'PHP', 'www.test9.com', 'test9', 'test', 'www.test9.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400),
(138, 'www.test10.com', '测试站10', 'PC', 'PHP', 'www.test10.com', 'test10', 'test', 'www.test10.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400),
(139, 'www.test11.com', '测试站11', 'PC', 'PHP', 'www.test11.com', 'test11', 'test', 'www.test11.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400),
(140, 'www.test12.com', '测试站12', 'PC', 'PHP', 'www.test12.com', 'test12', 'test', 'www.test12.com', 1546790400, 1546790400, '', '否', '无', '无', 1546790400, 1546790400),
(141, 'www.test13.com', '测试站13', 'PC', 'PHP', 'www.test13.com', 'test13', 'test', 'www.test13.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400),
(142, 'www.test14.com', '测试站14', 'PC', 'PHP', 'www.test14.com', 'test14', 'test', 'www.test14.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400),
(143, 'www.test15.com', '测试站15', 'PC', 'PHP', 'www.test15.com', 'test15', 'test', 'www.test15.com', 1546790400, 1546790400, '无', '否', '无', '无', 1546790400, 1546790400);

-- --------------------------------------------------------

--
-- 表的结构 `web_notices`
--

CREATE TABLE IF NOT EXISTS `web_notices` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '备忘录信息ID',
  `domain_id` int(6) unsigned DEFAULT NULL COMMENT '网站ID',
  `notice` varchar(512) DEFAULT NULL COMMENT '备忘信息内容',
  `notice_at` int(10) NOT NULL COMMENT '备忘添加时间',
  PRIMARY KEY (`id`),
  KEY `domain_id` (`domain_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='网站备忘录信息' AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `web_notices`
--

INSERT INTO `web_notices` (`id`, `domain_id`, `notice`, `notice_at`) VALUES
(2, 120, 'test1备忘录信息', 1546668610),
(3, 132, 'test5备忘录信息', 1546668710),
(4, 120, 'test1备忘信息2', 1546678561),
(5, 120, 'test1备忘信息3', 1546678983),
(6, 120, 'test1备忘4', 1546679073),
(7, 120, 'test备忘5', 1546679173),
(8, 120, 'test备忘6', 1546679251),
(9, 120, 'test备忘7', 1546679321),
(10, 120, 'test备忘8', 1546679366),
(13, 120, 'test备忘1023', 1546679637);

-- --------------------------------------------------------

--
-- 表的结构 `web_seo`
--

CREATE TABLE IF NOT EXISTS `web_seo` (
  `seo_id` int(6) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `domain_id` int(6) unsigned DEFAULT NULL COMMENT '网站ID',
  `seo_keywords` varchar(512) DEFAULT NULL COMMENT '网站关键词',
  PRIMARY KEY (`seo_id`),
  KEY `domain_id` (`domain_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='网站seo信息' AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `web_seo`
--

INSERT INTO `web_seo` (`seo_id`, `domain_id`, `seo_keywords`) VALUES
(4, 126, '测试站'),
(8, 120, 'keywords');

-- --------------------------------------------------------

--
-- 表的结构 `web_server`
--

CREATE TABLE IF NOT EXISTS `web_server` (
  `server_id` int(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '服务器信息ID',
  `domain_id` int(6) unsigned DEFAULT NULL COMMENT '网站ID',
  `ftp_ip` varchar(128) DEFAULT NULL COMMENT 'FTP登录地址',
  `ftp_user` varchar(32) DEFAULT NULL COMMENT 'FTP登录用户名',
  `ftp_pwd` varchar(32) DEFAULT NULL COMMENT 'FTP登录密码',
  `mysql_ip` varchar(128) DEFAULT NULL COMMENT 'MYSQL登录地址',
  `mysql_user` varchar(32) DEFAULT NULL COMMENT 'MYSQL登录用户名',
  `mysql_pwd` varchar(32) DEFAULT NULL COMMENT 'MYSQL登录密码',
  `console_domain` varchar(128) DEFAULT NULL COMMENT '控制台登录地址',
  `console_user` varchar(32) DEFAULT NULL COMMENT '控制台登录用户名',
  `console_pwd` varchar(32) DEFAULT NULL COMMENT '控制台登录密码',
  PRIMARY KEY (`server_id`),
  KEY `domain_id` (`domain_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='网站服务器信息' AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `web_server`
--

INSERT INTO `web_server` (`server_id`, `domain_id`, `ftp_ip`, `ftp_user`, `ftp_pwd`, `mysql_ip`, `mysql_user`, `mysql_pwd`, `console_domain`, `console_user`, `console_pwd`) VALUES
(1, 120, '127.0.0.1', 'root', 'root', '127.0.0.1', 'root', 'root', '127.0.0.1', 'root', 'root'),
(6, 126, '127.0.0.1', 'root4', 'root', '127.0.0.1', 'root4', 'root', '127.0.0.1', 'root4', 'root'),
(7, 134, '127.0.0.1', 'root2', 'root', '127.0.0.1', 'root2', 'root', '127.0.0.1', 'root2', 'root'),
(9, 139, '127.0.0.1', 'root11', 'root', '127.0.0.1', 'root11', 'root', '暂无', '暂无', '暂无'),
(13, 141, '127.0.0.1', 'root13', 'root', '127.0.0.1', 'root13', 'root', '暂无', '暂无', '暂无');

-- --------------------------------------------------------

--
-- 视图结构 `main_seo`
--
DROP TABLE IF EXISTS `main_seo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `main_seo` AS select `web_main`.`domain_id` AS `domain_id`,`web_main`.`domain` AS `domain`,`web_main`.`domain_name` AS `domain_name`,`web_main`.`web_type` AS `web_type`,`web_main`.`main_program` AS `main_program`,`web_main`.`host_url` AS `host_url`,`web_main`.`host_user` AS `host_user`,`web_main`.`host_pwd` AS `host_pwd`,`web_main`.`web_ldomain` AS `web_ldomain`,`web_main`.`web_lrat` AS `web_lrat`,`web_main`.`web_srat` AS `web_srat`,`web_main`.`web_refer` AS `web_refer`,`web_main`.`is_moblie` AS `is_moblie`,`web_main`.`mobile_refer` AS `mobile_refer`,`web_main`.`agent` AS `agent`,`web_main`.`domain_rat` AS `domain_rat`,`web_main`.`agent_rat` AS `agent_rat`,`web_seo`.`seo_id` AS `seo_id`,`web_seo`.`seo_keywords` AS `seo_keywords` from (`web_main` left join `web_seo` on((`web_main`.`domain_id` = `web_seo`.`domain_id`)));

-- --------------------------------------------------------

--
-- 视图结构 `main_server`
--
DROP TABLE IF EXISTS `main_server`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `main_server` AS select `web_main`.`domain_id` AS `domain_id`,`web_main`.`domain` AS `domain`,`web_main`.`domain_name` AS `domain_name`,`web_main`.`web_type` AS `web_type`,`web_main`.`main_program` AS `main_program`,`web_main`.`host_url` AS `host_url`,`web_main`.`host_user` AS `host_user`,`web_main`.`host_pwd` AS `host_pwd`,`web_main`.`web_ldomain` AS `web_ldomain`,`web_main`.`web_lrat` AS `web_lrat`,`web_main`.`web_srat` AS `web_srat`,`web_main`.`web_refer` AS `web_refer`,`web_main`.`is_moblie` AS `is_moblie`,`web_main`.`mobile_refer` AS `mobile_refer`,`web_main`.`agent` AS `agent`,`web_main`.`domain_rat` AS `domain_rat`,`web_main`.`agent_rat` AS `agent_rat`,`web_server`.`server_id` AS `server_id`,`web_server`.`ftp_ip` AS `ftp_ip`,`web_server`.`ftp_user` AS `ftp_user`,`web_server`.`ftp_pwd` AS `ftp_pwd`,`web_server`.`mysql_ip` AS `mysql_ip`,`web_server`.`mysql_user` AS `mysql_user`,`web_server`.`mysql_pwd` AS `mysql_pwd`,`web_server`.`console_domain` AS `console_domain`,`web_server`.`console_user` AS `console_user`,`web_server`.`console_pwd` AS `console_pwd` from (`web_main` left join `web_server` on((`web_main`.`domain_id` = `web_server`.`domain_id`)));

-- --------------------------------------------------------

--
-- 视图结构 `main_server_seo`
--
DROP TABLE IF EXISTS `main_server_seo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `main_server_seo` AS select `web_main`.`domain_id` AS `domain_id`,`web_main`.`domain` AS `domain`,`web_main`.`domain_name` AS `domain_name`,`web_main`.`web_type` AS `web_type`,`web_main`.`main_program` AS `main_program`,`web_main`.`host_url` AS `host_url`,`web_main`.`host_user` AS `host_user`,`web_main`.`host_pwd` AS `host_pwd`,`web_main`.`web_ldomain` AS `web_ldomain`,`web_main`.`web_lrat` AS `web_lrat`,`web_main`.`web_srat` AS `web_srat`,`web_main`.`web_refer` AS `web_refer`,`web_main`.`is_moblie` AS `is_moblie`,`web_main`.`mobile_refer` AS `mobile_refer`,`web_main`.`agent` AS `agent`,`web_main`.`domain_rat` AS `domain_rat`,`web_main`.`agent_rat` AS `agent_rat`,`web_server`.`server_id` AS `server_id`,`web_server`.`ftp_ip` AS `ftp_ip`,`web_server`.`ftp_user` AS `ftp_user`,`web_server`.`ftp_pwd` AS `ftp_pwd`,`web_server`.`mysql_ip` AS `mysql_ip`,`web_server`.`mysql_user` AS `mysql_user`,`web_server`.`mysql_pwd` AS `mysql_pwd`,`web_server`.`console_domain` AS `console_domain`,`web_server`.`console_user` AS `console_user`,`web_server`.`console_pwd` AS `console_pwd`,`web_seo`.`seo_id` AS `seo_id`,`web_seo`.`seo_keywords` AS `seo_keywords` from ((`web_main` left join `web_server` on((`web_main`.`domain_id` = `web_server`.`domain_id`))) left join `web_seo` on((`web_main`.`domain_id` = `web_seo`.`domain_id`)));

--
-- 限制导出的表
--

--
-- 限制表 `web_notices`
--
ALTER TABLE `web_notices`
  ADD CONSTRAINT `web_notices_ibfk_1` FOREIGN KEY (`domain_id`) REFERENCES `web_main` (`domain_id`);

--
-- 限制表 `web_seo`
--
ALTER TABLE `web_seo`
  ADD CONSTRAINT `web_seo_ibfk_1` FOREIGN KEY (`domain_id`) REFERENCES `web_main` (`domain_id`);

--
-- 限制表 `web_server`
--
ALTER TABLE `web_server`
  ADD CONSTRAINT `web_server_ibfk_1` FOREIGN KEY (`domain_id`) REFERENCES `web_main` (`domain_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
